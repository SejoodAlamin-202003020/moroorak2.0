package com.example.temp_fix_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
